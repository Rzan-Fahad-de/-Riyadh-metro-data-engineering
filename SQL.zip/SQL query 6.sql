CREATE TABLE dbo.UserStationAccess
(
    User_Email VARCHAR(8000),
    Station_ID VARCHAR(8000)
);

INSERT INTO dbo.UserStationAccess
(
    User_Email,
    Station_ID
)
VALUES
(
    'TU4356977@taibahu.edu.sa',
    '3'
);

SELECT *
FROM dbo.UserStationAccess;