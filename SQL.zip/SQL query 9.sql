DROP SECURITY POLICY MetroStationSecurityPolicy;

DROP FUNCTION dbo.fn_StationManagerAccess;


SELECT name, type_desc
FROM sys.objects
WHERE name IN ('MetroStationSecurityPolicy', 'fn_StationManagerAccess');


SELECT
    name,
    is_masked,
    masking_function
FROM sys.masked_columns
WHERE object_id = OBJECT_ID('dbo.fact_trips');

ALTER TABLE dbo.fact_trips
ALTER COLUMN Passenger_Count
DROP MASKED;

SELECT
    name,
    is_masked,
    masking_function
FROM sys.masked_columns
WHERE object_id = OBJECT_ID('dbo.fact_trips');