DROP TABLE dbo.dim_lines;

CREATE TABLE dbo.dim_lines
(
    Line_ID INT,
    Line_Number VARCHAR(50),
    Line_Name VARCHAR(100),
    Terminal_Stations VARCHAR(500),
    Route_Color VARCHAR(50),
    Geo_Coordinates VARCHAR(500),
    Geo_Point VARCHAR(500)
);

INSERT INTO dbo.dim_lines
(
    Line_ID,
    Line_Number,
    Line_Name,
    Terminal_Stations,
    Route_Color,
    Geo_Coordinates,
    Geo_Point
)
SELECT
    Line_ID,
    Line_Number,
    Line_Name,
    Terminal_Stations,
    Route_Color,
    Geo_Coordinates,
    Geo_Point
FROM [Riyadh_Metro_Lakehouse].[dbo].[gold_metro_lines];

SELECT *
FROM dbo.dim_lines
ORDER BY Line_ID;