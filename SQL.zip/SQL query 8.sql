ALTER TABLE dbo.fact_trips
ALTER COLUMN Passenger_Count
ADD MASKED WITH (FUNCTION = 'default()');


SELECT *
FROM sys.masked_columns
WHERE object_id = OBJECT_ID('dbo.fact_trips');