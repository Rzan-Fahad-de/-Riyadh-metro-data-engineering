CREATE FUNCTION dbo.fn_StationManagerAccess
(
    @StartStationID VARCHAR(8000),
    @EndStationID VARCHAR(8000)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    SELECT 1 AS AccessResult
    FROM dbo.UserStationAccess AS A
    WHERE A.User_Email = USER_NAME()
      AND
      (
          A.Station_ID = @StartStationID
          OR
          A.Station_ID = @EndStationID
      )
);
GO


CREATE SECURITY POLICY MetroStationSecurityPolicy
ADD FILTER PREDICATE dbo.fn_StationManagerAccess
(
    Start_Station_ID,
    End_Station_ID
)
ON dbo.fact_trips
WITH (STATE = ON);
GO


SELECT USER_NAME() AS Current_User;
GO


SELECT *
FROM dbo.fact_trips;