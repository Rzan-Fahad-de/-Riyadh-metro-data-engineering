CREATE TABLE dbo.dim_stations
(
    Station_ID INT,
    Station_Code VARCHAR(8000),
    Station_Name VARCHAR(8000),
    Station_Name_AR VARCHAR(8000),
    Line_ID VARCHAR(8000),
    Line_Name VARCHAR(8000),
    Station_Type VARCHAR(8000),
    Station_Type_AR VARCHAR(8000),
    Station_Sequence INT,
    Geo_Coordinates VARCHAR(8000),
    Geo_Point VARCHAR(8000)
);

INSERT INTO dbo.dim_stations
(
    Station_ID,
    Station_Code,
    Station_Name,
    Station_Name_AR,
    Line_ID,
    Line_Name,
    Station_Type,
    Station_Type_AR,
    Station_Sequence,
    Geo_Coordinates,
    Geo_Point
)
SELECT
    Station_ID,
    Station_Code,
    Station_Name,
    Station_Name_AR,
    Line_ID,
    Line_Name,
    Station_Type,
    Station_Type_AR,
    Station_Sequence,
    Geo_Coordinates,
    Geo_Point
FROM [Riyadh_Metro_Lakehouse].[dbo].[gold_metro_stations];

SELECT *
FROM dbo.dim_stations
ORDER BY Station_ID;