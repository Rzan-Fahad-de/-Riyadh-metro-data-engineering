CREATE TABLE dbo.fact_trips
(
    Trip_ID VARCHAR(8000),
    Line_ID VARCHAR(8000),
    Line_Name VARCHAR(8000),
    Start_Station_ID VARCHAR(8000),
    Start_Station_Name VARCHAR(8000),
    Start_Station_Name_AR VARCHAR(8000),
    End_Station_ID VARCHAR(8000),
    End_Station_Name VARCHAR(8000),
    End_Station_Name_AR VARCHAR(8000),
    Departure_Time DATETIME2(6),
    Arrival_Time DATETIME2(6),
    Trip_Duration_Minutes FLOAT,
    Passenger_Count INT,
    Status VARCHAR(8000)
);

INSERT INTO dbo.fact_trips
(
    Trip_ID,
    Line_ID,
    Line_Name,
    Start_Station_ID,
    Start_Station_Name,
    Start_Station_Name_AR,
    End_Station_ID,
    End_Station_Name,
    End_Station_Name_AR,
    Departure_Time,
    Arrival_Time,
    Trip_Duration_Minutes,
    Passenger_Count,
    Status
)
SELECT
    Trip_ID,
    Line_ID,
    Line_Name,
    Start_Station_ID,
    Start_Station_Name,
    Start_Station_Name_AR,
    End_Station_ID,
    End_Station_Name,
    End_Station_Name_AR,
    Departure_Time,
    Arrival_Time,
    Trip_Duration_Minutes,
    Passenger_Count,
    Status
FROM [Riyadh_Metro_Lakehouse].[dbo].[gold_metro_trips];

SELECT *
FROM dbo.fact_trips;