CREATE TABLE dbo.dim_events
(
    Event_ID BIGINT,
    Event_Name VARCHAR(8000),
    Event_Type VARCHAR(8000),
    City VARCHAR(8000),
    Venue VARCHAR(8000),
    Latitude FLOAT,
    Longitude FLOAT,
    Start_Date DATETIME2(6),
    End_Date DATETIME2(6),
    Source VARCHAR(8000)
);

INSERT INTO dbo.dim_events
(
    Event_ID,
    Event_Name,
    Event_Type,
    City,
    Venue,
    Latitude,
    Longitude,
    Start_Date,
    End_Date,
    Source
)
SELECT
    Event_ID,
    Event_Name,
    Event_Type,
    City,
    Venue,
    Latitude,
    Longitude,
    Start_Date,
    End_Date,
    Source
FROM [Riyadh_Metro_Lakehouse].[dbo].[gold_metro_events];

SELECT *
FROM dbo.dim_events
ORDER BY Event_ID;