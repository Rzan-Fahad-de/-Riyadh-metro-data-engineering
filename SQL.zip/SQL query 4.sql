CREATE TABLE dbo.dim_weather
(
    Weather_Time DATETIME2(6),
    Temperature FLOAT,
    Humidity BIGINT,
    Precipitation FLOAT,
    Wind_Speed FLOAT
);

INSERT INTO dbo.dim_weather
(
    Weather_Time,
    Temperature,
    Humidity,
    Precipitation,
    Wind_Speed
)
SELECT
    Weather_Time,
    Temperature,
    Humidity,
    Precipitation,
    Wind_Speed
FROM [Riyadh_Metro_Lakehouse].[dbo].[gold_metro_weather];

SELECT *
FROM dbo.dim_weather
ORDER BY Weather_Time;